<div class="row">
			<div class="col-md-12">
				<center>Copyright &copy 2023 | AN-NIDA BOARDING SCHOOL | An-Nida Group<br/></center>
			</div>
			</div>
	</div><!-- Akhir FOOTER -->
		
<script src="../bootstrap/js/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../bootstrap/js/dataTables.bootstrap.min.js"></script>
<script src="../bootstrap/js/jquery.dataTables.js"></script>
<script src="../bootstrap/js/scripts.js"></script>

</script>
</body>
</html>