<!-- FOOTER -->

		<div class="row">
			<div class="col-md-12">
				<center>Copyright &copy 2023 | AN-NIDA BOARDING SCHOOL | An-Nida Group<br/>
			</div>
			</div>
	</div><!-- Akhir FOOTER -->