<?php include "header.php";?>
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-12"><!-- Awal kolom pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<center><h2 style="text-muted"></span> PENERIMAAN GURU & KARYAWAN ANBS P. BERANDAN </h2></center>
				
				<img src="images/guru.jpeg" class="img-thumbnail img-responsive"><p><br>

						<ul><p>PENERIMAAN GURU & KARYAWAN ANBS P. BERANDAN<p><br>
Formasi:<p>
1. Guru PJOK SMP (Perempuan)<p>
2. Guru IPS SMP (Laki-laki/ Perempuan)<p>
3. Guru Sejarah SMA (Laki-laki/ Perempuan)<p>
4. Guru Bahasa Indonesia SMA (Laki-laki/ Perempuan)<p>
5. Guru Geografi SMA (Laki-laki/ Perempuan)<p>
6. Guru PKN SMA (Laki-laki/ Perempuan)<p>
7. Guru Sejarah/ Tarikh SMA (Laki-laki/ Perempuan)<p>
8. Guru Matematika SMA (Laki-laki/ Perempuan)<p><br>

Kualifikasi:<p>
- Berpenampilan syar'i dan berakhlak baik serta profesional di bidangnya<p>
- IPK minimal 3.00 (skala 4.00)<p>
- Pendidikan minimal S1 untuk semua formasi dari program studi pendidikan<p>
- Usia maksimal 30 tahun<p>
- Tidak merokok atau terlibat narkotika<p>
- Bersedia bekerja di lingkungan yang islami<p>
- Tidak sedang menempuh studi S2/S3/Profesi<p>
- Siap ditempatkan di Payakumbuh dan Harau (Lima Puluh Kota)<p>
- Tidak sedang mengikuti proses seleksi di instansi lain<p><br>

Persyaratan Administrasi:<p>
- Surat lamaran tulis tangan (sendiri) ditujukan kepada Bagian SDM ANBS P. Berandan<p>
- Curriculum Vitae (CV) terbaru<p>
- Fotokopi KTP & KK<p>
- Foto diri terbaru berwarna ukuran 4 x 6 (1 lembar)<p>
- Fotokopi ijazah & transkrip nilai pendidikan terakhir (dilegalisir)<p>
- Fotokopi piagam penghargaan/ sertifikat keahlian/ sertifikat pelatihan/ seminar<p>
- Surat pengalaman kerja bila memiliki<p>
- Surat keterangan lulus dan nilai akademik dari universitas (bila belum memiliki ijazah resmi)<p>
- SKCK terbaru/masih berlaku<p><br>

Berkas persyaratan administrasi dibawa pelamar ketika seleksi tes akademik dan wawancara di P. Berandan<p>

Pada amplop dituliskan:<p>
- Nama pelamar<p>
- Formasi<p>
- Nomor WhatsApp yang bisa dihubungi<p><br>

Tahap Seleksi (semua tahapan dilakukan secara tatap muka):<p>
1. Registrasi pendaftaran online 19 - 27 Januari 2023 (www.annida.ac.id/recruitment/)<p>
2. Pengumuman lulus seleksi kualifikasi 3 Februari 2024 via website www.annida.ac.id<p>
3. Bagi peserta yang lulus tes administrasi, akan melaksanakanan interview pada tanggal 06 Februari 2024<p>
4. Untuk teknis dan ketentuan lainnya akan diinformasikan kemudian<p><br>

Info lebih lanjut:<p>
- 085234567890 (Ust. Achmad Fadhlan Yazid, S.T., M.Si)<p>
- 082345678901 (Ust. Exdibar Nofri, S.E., MM)<p>
- email: bs@annida.ac.id<p></p>

<a href="https://docs.google.com/forms/d/1ELUPcZxwDcmZ9MlyJ6wAskGgqIZzXA72X1hJKix8GeI/prefill">FORMULIR PENDAFTARAN CALON PEGAWAI ANBS P. BERANDAN</a></ul>
				</div>
      </div>
			</div><!-- Akhir Kolom pertama -->