<?php include "header.php";?>
		<!-- Awal Page -->
		<div class="container">
		<!-- Awal baris -->
		<div class="row">
			<div class="col-md-12"><!-- Awal kolom pertama -->
			<div class="panel panel-default">
				<div class="panel-body">
				<center><h2 style="text-muted"></span> VISI DAN MISI AN-NIDA BOARDING SCHOOL </h2></center>
				
				<img src="images/visi.jpeg" class="img-thumbnail img-responsive"><p><br>

						<ul><p><b> VISI DAN MISI AN-NIDA BOARDING SCHOOL </b><p><br>
Visi:<p>
Menjadi lembaga pendidikan yang terdepan dan unggul.<p>
<br>

Misi:<p>
1. Memberikan kontribusi terbaik dalam mengembangkan masyarakat melalui pembinaan warga negara dengan berlandaskan budaya keilmuan;<p>
2. Meningkatkan kualitas SDM;<p>
3. Meningkatkan kualitas dan kuantitas pendidikan dan pengajaran;<p>
4. Menerapkan sistem manajemen mutu secara komprehensif;<p>
5. Menjalin kerjasama dengan orang tua, masyarakat dan pemerintah.<p></ul>
				</div>
            </div>
			</div><!-- Akhir Kolom pertama -->